The parts rotation_new(wrist pin) and pinza_new(end effector), may not be shown(accessible) while opening the assembly model. But these parts can be viewed separately by opening their respective part files.
We are encountering a Client server error,while trying to access all parts to be open in assembly.
  The assembly is only opening completely in the workspace which was used to create these files(as shown in scrrenshot).Fot that particular workspace,even if the assembly is opened from a removable harddisk, it is fetching the 2 parts from the server documents.
